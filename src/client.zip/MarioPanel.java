package client;

public class MarioPanel {

}
