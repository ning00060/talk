package client;

public class ZeldaPanel {

}
