package client;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import lombok.Data;

@Data
public class ClientFrame extends JFrame {

	private Client client;

	private Image backgroundImage;
	private JTabbedPane tabPane;
	private JPanel mainPanel;
	private LoginPanel loginPanel;
	private LoungePanel loungePanel;
	private MessagePanel messagePanel;

	public ClientFrame(Client client) {
		this.client = client;
		loginPanel = new LoginPanel(client);
		loungePanel = new LoungePanel(client);
		backgroundImage = new ImageIcon("images/IMG_9023.png").getImage();
		initData();
		setInitLayout();
		addEventListener();
	}

	public void initData() {
		tabPane = new JTabbedPane(JTabbedPane.TOP);
		mainPanel = new JPanel();
		loginPanel = new LoginPanel(client);
		loungePanel = new LoungePanel(client);
		messagePanel = new MessagePanel(client);
	}

	public void setInitLayout() {
		setTitle("프로토타입");
		setSize(1000, 506);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		mainPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		mainPanel.setLayout(null);
		setContentPane(mainPanel);

		tabPane.setBounds(0, 0, getWidth(), getHeight());
		mainPanel.add(tabPane);
		loginPanel.setLayout(null);
		tabPane.addTab("로그인", null, loginPanel, null);
//		tabPane.addTab("채팅", null, messagePanel, null);

	}

	public void addEventListener() {

	}

	protected void paintComponent(Graphics g) {
		super.paintComponents(g);
		g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
	}
}
