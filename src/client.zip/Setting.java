package client;

public abstract interface Setting {
	

}
