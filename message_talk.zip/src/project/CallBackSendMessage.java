package project;

public interface CallBackSendMessage {
	void sendMessage(String messageText);
}
